from django.contrib import admin
from django.conf.urls import url
from . import views
from blog.views import IndexView

urlpatterns = [
    #url(r'^$', views.index, name='index'),
    url(r'^$', IndexView.as_view(), name='index'),
    url(r'^blog/$', views.blog, name='blog'),
    url(r'^blog/(?P<id>[0-9]+)/$', views.post_detail, name='detail'),
    url(r'^blog/add/$', views.add_post, name='add'),
    url(r'^blog/(?P<id>[0-9]+)/edit/$', views.edit_post, name='edit'),
    url(r'^blog/(?P<id>[0-9]+)/delete$', views.delete_post, name='delete'),
    url(r'^blog/(?P<id>\w{0,50})/comment/$', views.comment, name="post_comment"),
    url(r'^blog/(?P<id>\w{0,50})/comment/add_comment/$', views.add_comment, name="add_comment"),
    url(r'^contact/', views.contact, name="contact")

]
