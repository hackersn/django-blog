from django.shortcuts import render, redirect, get_object_or_404
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
from django.utils import timezone
from .models import Post, Comment
from .forms import PostForm, CommentForm
from django.views.generic import TemplateView
# Create your views here.

"""def index(request):
    title = "Welcome To Daara_IT"
    return render(request, "blog/index.html", {"title": title})
"""

class IndexView(TemplateView):
    template_name = "blog/index.html"
    def get(self, request):
        title = "Welcome To Daara_IT"
        return render(request, self.template_name, {"title": title})

def blog(request):
    posts = Post.objects.all().order_by("-published")
    page = request.GET.get('page', 1)
    paginator = Paginator(posts, 5)
    posts = paginator.get_page(page)
    return render(request, "blog/blog.html", {"posts": posts})

def post_detail(request, id):
    post = get_object_or_404(Post, id=id)
    c_number = len(Comment.objects.filter(post_id=id))
    context = {
        'post': post,
        'c_number': c_number,
    }
    return render(request, "blog/post_detail.html", context)

def add_post(request):
    if request.method == "POST":
        form = PostForm(request.POST)
        if form.is_valid():
            post = form.save(commit = False)
            post.author = request.user
            post.published = timezone.now()
            post.save()
            return redirect("blog")
    else:
        form = PostForm()
        return render(request, "blog/add_post.html", {"form": form })

def edit_post(request, id):
    post = get_object_or_404(Post, id=id)
    if request.method == "POST":
        form = PostForm(request.POST, instance=post)
        if form.is_valid():
            post = form.save(commit = False)
            post.author = request.user
            post.save()
            return redirect("detail", post.id)
    else:
        form = PostForm(instance=post)
        return render(request, "blog/add_post.html", {"form": form })

def delete_post(request, id):
    if request.user.is_superuser:
        post = get_object_or_404(Post, id=id)
    else:
        post = get_object_or_404(Post, id=id, user=request.user)
    if request.method=="POST":
        post.delete()
        return redirect("blog")
    else:
        return render(request, "blog/delete_post.html", {"post": post})

def add_comment(request, id):
    if request.method == 'POST':
        form = CommentForm(request.POST)
        if form.is_valid():
            comment = form.save(commit=False)
            comment.name = request.POST['name']
            comment.comment = request.POST['comment']
            comment.post_id = id
            comment.save()
        return redirect('detail', id = id)
    else:
            form = CommentForm()
            return render(request,'blog/add_comment.html', {'form':form})

def comment(request,id):
    comments = Comment.objects.filter(post_id=id)
    p_id = id
    return render(request, 'blog/comment.html', {'comments':comments, 'p_id':p_id})

def contact(request):
    return render(request, "blog/contact.html")
