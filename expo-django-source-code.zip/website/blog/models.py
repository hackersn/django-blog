from django.db import models
from django.utils import timezone
# Create your models here.


class Post(models.Model):
    author = models.ForeignKey("auth.User", on_delete=models.CASCADE)
    title = models.CharField(max_length=200)
    content = models.TextField()
    picture = models.URLField()
    created = models.DateTimeField(default=timezone.now)
    published = models.DateTimeField(default=timezone.now)


    def publish(self):
        self.publish = timezone.now()
        return self.published

    def __str__(self):
        return self.title

class Comment(models.Model):
    name = models.CharField(max_length=50)
    comment = models.TextField()
    post_id = models.IntegerField(default=0)

    def __str__(self):
        return self.comment